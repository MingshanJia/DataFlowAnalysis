#include <iostream>
#include <cstdio>
using namespace std;
const int MAXN=305;
int T,n,p,p2,nums[MAXN],ans[MAXN];
bool flag[MAXN];
int main()
{
    freopen("A-large.txt","r",stdin);
    freopen("OUT12.txt","w",stdout);
    scanf("%i",&T);
    for (int t=1;t<=T;t++)
    {
        scanf("%i",&n);
        p=0;
        for (int i=1;i<=2*n;i++)
        {
            scanf("%i",&nums[i]);
            flag[i]=false;
        }
        for (int i=1;i<=2*n;i++)
        {
            if (!flag[i])
            {
                flag[i]=true;
                ans[p++]=nums[i];
                p2=(long long)4*(nums[i])/3;
                for (int j=i+1;j<=2*n;j++)
                {
                    if (nums[j]==p2 && !flag[j])
                    {
                        flag[j]=true;
                        break;
                    }
                }
            }
        }
        printf("Case #%i: ",t);
        for (int i=0;i<n;i++)printf("%i ",ans[i]);
        printf("\n");
    }
}
